from .extension import FlaskAssistants  # This imports the main class of the extension.

__all__ = ['Assistant']
